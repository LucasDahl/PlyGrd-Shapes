//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        
// MARK: - Initial setup =================
        // Create the view
        let view = UIView()
        
        // Sets the background color
        view.backgroundColor = .white
// End setup =============================
        
        // Setup the frame
        let frame = CGRect(x: 150, y: 150, width: 200, height: 200)

        
// MARK: - Square======================
        
        let subView = UIView(frame: frame)
        subView.backgroundColor = .red
        
        
// MARK: - Finish setup ===============
        // Add the view to the subview
        view.addSubview(subView)
        
        // Set the view to self
        self.view = view
// MARK: - End =======================
        
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
