//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

// Screen setup
let screenWidth = 375.0 // points
let screenHeight = 667.0 // points
// Calculate center (x, y)
let centerX = screenWidth / 2
let centerY = screenHeight / 2
// Express the center (x, y) coordinate of the screen as a CGPoint
let screenCenterCoordinate = CGPoint(x: centerX, y: centerY)
// Define the dimensions of the square (width = height)
let squareSide = 200.0

class MyViewController : UIViewController {
    override func loadView() {
        
// MARK: - Initial setup =================
        // Create the view
        let view = UIView()
        
        // Sets the background color
        view.backgroundColor = .white
// End setup =============================

// MARK: - Square======================
        
        // Create the sunView(square)
        let subView = UIView()
        
        // Size the square and view effectively
        // Use its bounds to position it
        // Use the center value
        subView.frame = CGRect(x: 0.0, y: 0.0, width: squareSide, height: squareSide)
        
        // Set the center
        subView.center = screenCenterCoordinate
        
        // Round the corners
        subView.layer.cornerRadius = 10
        
        // Set the alpha of the square(subView) to 0(invisable)
        subView.alpha = 0
        
        // Set the background color
        subView.backgroundColor = .red
        
// MARK: - Animate the Square =========
        
        UIView.animate(withDuration: 5.0) {
            
            // Chnage the alpha to 1(or visiable)
            subView.alpha = 1
            
            // Setup the roation angle
            let affineTransform = CGAffineTransform(rotationAngle:  CGFloat(Double.pi))
            // Setup the transform(animation
            subView.transform = affineTransform
            
            // Change the color to blue
            subView.backgroundColor = .blue
            
        }
        
// End animating the square ===========
        
// MARK: - Finish setup ===============
        // Add the view to the subview
        view.addSubview(subView)
        
        // Set the view to self
        self.view = view
// MARK: - End =======================
        
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()

